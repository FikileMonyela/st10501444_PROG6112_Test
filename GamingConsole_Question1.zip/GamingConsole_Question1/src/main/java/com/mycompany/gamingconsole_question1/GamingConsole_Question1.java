/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gamingconsole_question1;

/**
 *
 * @author Student
 */
public class GamingConsole_Question1 {

    public static void main(String[] args) {
        
        //Declaration of Arrays
        int [][] sales ={{1000,2000,3000},
                         {2000,3000,4000},
                         {1500,1100,1200}
                        };
        
        String [] cities= {"Cape Town", "PORT ELIZABETH","PRETORIA"};
        String [] games ={"PSS","XBOX","SWITCH"};
        
        int [] totalSales = new int[3];
        
        
        System.out.println("-----------------------------------------");
        System.out.println("Gaming console report ");
        System.out.println("---------------------------------------- ");
        
        //for loop to print out the table
        System.out.println("\t\t" +games[0]+ "\t" +games[1]+ "\t" +games[2]);
        for(int i=0; i<sales.length; i++){
            System.out.print(cities[i]+ "\t");
            
            //temporaray loop control variable
            int currentCity=0;
            
            for(int j=0; j<sales[i].length; j++){
                System.out.print(sales[i][j]+ "\t");
                
                //calcualtes the total sales for each city
                currentCity += sales[i][j];
                
            }
            totalSales[i] = currentCity;
            System.out.println();
        }
        
        
        System.out.println("-----------------------------------------");
        System.out.println("Console sales totals for each city ");
        System.out.println("---------------------------------------- ");
        
        String finalCity= cities[1];
        int   finalSale = totalSales[0];
        
        for(int i=0; i<sales.length; i++){
            System.out.println( cities[i]+ "\t" + totalSales[i]);
            
           
        }
         System.out.println("City with the most sales: " +finalCity);
        System.out.println();
        
        
        
        
        
    }
}

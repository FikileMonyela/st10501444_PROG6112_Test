/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.electronicstore_question2;

/**
 *
 * @author Student
 */
public abstract class Consoles implements IConsole {
    //declarattion
    String deviceType;
    String storeName;
    int totalAmountOfSales;
    
    //A constructor
    public Consoles( String deviceType,String storeName, int totalAmountOfSales ){
        this.deviceType =deviceType;
        this.storeName = storeName;
        this.totalAmountOfSales = totalAmountOfSales;
        
    }
    
    //The interface and the class share the same methods that's why they override
    //get method returns the declared variables
    @Override
    public String getConsoleType(){
        return this.deviceType;
    }
    
    @Override
    public String getStore(){
        return  this.storeName;
    
}
    @Override
    public int getTotalSales(){
       return this.totalAmountOfSales;
    }
}

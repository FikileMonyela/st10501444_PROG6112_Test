/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.electronicstore_question2;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class ElectronicStore_Question2 {

    public static void main(String[] args) {
        
        //created a scanner for users input
        Scanner input = new Scanner(System.in);
        
        //A menu for a user to choose from
        System.out.println("Select the beverage type");
        System.out.println("1.PSS");
        System.out.println("2.XBOX");
        System.out.println("3.SWITCH");
        
        int choice = input.nextInt();
        input.nextLine();
        
        String deviceType = " ";
        if(choice==1) deviceType ="PSS";
        else if (choice ==2) deviceType ="XBOX";
        else if (choice ==3) deviceType ="SWITCH";
        
        
        //print statement
        System.out.println("Enter the store: ");
        String storeName = input.nextLine();
        
        System.out.println("Enter the total sales of PSS for Number 1 Electronics Store:" );
        int  totalAmountOfSales = input.nextInt();
        
        //An object to store the class Console Sales
        ConsoleSales cs = new ConsoleSales (deviceType, storeName, totalAmountOfSales);
        
        //Calls the print Report
        cs.printReport();
        
        //Scanner closes
        input.close();
    }
}

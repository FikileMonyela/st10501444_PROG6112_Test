/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.electronicstore_question2;

/**
 *
 * @author Student
 */
public class ConsoleSales extends Consoles {
    
    public ConsoleSales(String deviceType, String storeName, int totalAmountOfSales) {
        super(deviceType, storeName, totalAmountOfSales);
        
    }
    
    //print method to print report
    public void printReport(){
        System.out.println(" CONSOLE SALES REPORT");
        System.out.println("**************************");
        
        System.out.println(" CONSOLE TYPE:" +getConsoleType());
        System.out.println(" STORE:" +getStore());
        System.out.println(" TOTAL SALES:" +getTotalSales());
        
        
    }
}
